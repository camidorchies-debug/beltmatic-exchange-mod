@echo off
setlocal

set "GAME_DIR=%~1"
if "%GAME_DIR%"=="" set "GAME_DIR=C:\Users\camid\Desktop\Beltmatic.v1.0.9\Beltmatic.v1.0.5\Beltmatic.v1.0.5"

if not exist "%GAME_DIR%\MelonLoader\Il2CppAssemblies\Assembly-CSharp.dll" (
  echo.
  echo Je ne trouve pas Assembly-CSharp.dll dans :
  echo   %GAME_DIR%
  echo.
  set /p "GAME_DIR=Entre le chemin complet du dossier Beltmatic : "
)

if not exist "%GAME_DIR%\MelonLoader\Il2CppAssemblies\Assembly-CSharp.dll" (
  echo ERREUR : impossible de trouver MelonLoader\Il2CppAssemblies\Assembly-CSharp.dll.
  echo Verifie le chemin du jeu et que MelonLoader a deja ete lance.
  pause
  exit /b 1
)

where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERREUR : le SDK .NET n'est pas installe ou la commande dotnet est introuvable.
  echo Installe le SDK .NET 6 puis relance build.bat.
  pause
  exit /b 1
)

echo Compilation de Beltmatic Exchange...
dotnet build BeltmaticExchange.csproj -c Release "-p:GameDir=%GAME_DIR%"
if errorlevel 1 (
  echo.
  echo La compilation a echoue. Lis les erreurs ci-dessus.
  pause
  exit /b 1
)

if not exist "%GAME_DIR%\Mods" mkdir "%GAME_DIR%\Mods"
copy /Y "bin\Release\net6.0\BeltmaticExchange.dll" "%GAME_DIR%\Mods\BeltmaticExchange.dll" >nul
if errorlevel 1 (
  echo ERREUR : compilation terminee, mais la DLL n'a pas pu etre copiee dans Mods.
  pause
  exit /b 1
)

echo.
echo OK ! BeltmaticExchange.dll a ete copie dans :
echo   %GAME_DIR%\Mods\BeltmaticExchange.dll
echo Lance Beltmatic pour tester le mod.
pause
