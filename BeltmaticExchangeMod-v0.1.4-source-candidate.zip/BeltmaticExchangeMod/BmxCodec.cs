using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Xml;
using BclXDocument = System.Xml.Linq.XDocument;
using BclXElement = System.Xml.Linq.XElement;

namespace BeltmaticExchange;

/// <summary>
/// Codec for Beltmatic Exchange's .bmx JSON format and BMX1: clipboard string.
/// Keeps the game's native Blueprint XML intact for import back into Beltmatic.
/// </summary>
internal static class BmxCodec
{
    private const string FormatId = "beltmatic-machine";
    private const int FormatVersion = 1;
    private const string ClipboardPrefix = "BMX1:";
    private const int MaxTextChars = 700_000;
    private const int MaxJsonBytes = 2_000_000;
    private const int MaxNativeXmlChars = 300_000;
    private const int MaxBuildings = 10_000;

    private static readonly JsonSerializerOptions PrettyJson = new()
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    private static readonly JsonSerializerOptions CompactJson = new()
    {
        WriteIndented = false,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    internal sealed class Machine
    {
        [JsonPropertyName("format")] public string Format { get; set; } = FormatId;
        [JsonPropertyName("version")] public int Version { get; set; } = FormatVersion;
        [JsonPropertyName("name")] public string Name { get; set; } = "Beltmatic blueprint";
        [JsonPropertyName("game_version")] public string GameVersion { get; set; } = "1.0.5";
        [JsonPropertyName("width")] public int Width { get; set; } = 1;
        [JsonPropertyName("height")] public int Height { get; set; } = 1;
        [JsonPropertyName("native_xml")] public string NativeXml { get; set; } = "";
        [JsonPropertyName("buildings")] public List<MachinePart> Buildings { get; set; } = new();
    }

    internal sealed class MachinePart
    {
        [JsonPropertyName("type")] public string Type { get; set; } = "belt";
        [JsonPropertyName("x")] public int X { get; set; }
        [JsonPropertyName("y")] public int Y { get; set; }
        [JsonPropertyName("rot")] public int Rotation { get; set; }
        [JsonPropertyName("w")] public int Width { get; set; } = 1;
        [JsonPropertyName("h")] public int Height { get; set; } = 1;
        [JsonPropertyName("prio")] [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)] public bool Priority { get; set; }
        [JsonPropertyName("outs")] public List<int> Outputs { get; set; }
        [JsonPropertyName("flows")] public List<int> Flows { get; set; }
        [JsonPropertyName("half")] public string Half { get; set; }
        [JsonPropertyName("value")] public string Value { get; set; }
    }

    internal static Machine FromNativeXml(string nativeXml, string name, string gameVersion)
    {
        nativeXml = ExtractBlueprintXml(nativeXml);
        if (nativeXml.Length > MaxNativeXmlChars)
            throw new InvalidDataException($"Le blueprint XML dépasse la limite du site ({MaxNativeXmlChars} caractères).");

        var xml = ParseSafeXml(nativeXml);
        BclXElement blueprint = FindBlueprint(xml);
        var machine = new Machine
        {
            Name = CleanName(name),
            GameVersion = gameVersion,
            NativeXml = nativeXml
        };

        string size = (string)blueprint.Attribute("Size");
        if (!string.IsNullOrWhiteSpace(size))
        {
            string[] pair = size.Split(',');
            if (pair.Length == 2 && int.TryParse(pair[0].Trim(), out int w) && int.TryParse(pair[1].Trim(), out int h))
            {
                machine.Width = Math.Clamp(w, 1, 512);
                machine.Height = Math.Clamp(h, 1, 512);
            }
        }

        // Game XML stores regular buildings as groups of four: type, x, y, rotation.
        string buildingData = ChildData(blueprint, "Buildings");
        if (!string.IsNullOrWhiteSpace(buildingData))
        {
            string[] fields = SplitData(buildingData);
            if (fields.Length % 4 != 0)
                throw new InvalidDataException("Le bloc Buildings du XML natif est incomplet.");

            for (int i = 0; i < fields.Length; i += 4)
            {
                string type = Slug(fields[i]);
                int x = ParseInt(fields[i + 1], "x bâtiment");
                int y = ParseInt(fields[i + 2], "y bâtiment");
                int rot = NormalizeDirection(ParseInt(fields[i + 3], "rotation bâtiment"));
                var part = new MachinePart { Type = type, X = x, Y = y, Rotation = rot };
                SetKnownSize(part);
                machine.Buildings.Add(part);
            }
        }

        // Belt records are groups of eight. The first two values are coordinates and the
        // third is the main direction. The remaining values stay losslessly preserved in native_xml.
        string beltData = ChildData(blueprint, "Belts");
        if (!string.IsNullOrWhiteSpace(beltData))
        {
            string[] fields = SplitData(beltData);
            if (fields.Length % 8 != 0)
                throw new InvalidDataException("Le bloc Belts du XML natif est incomplet.");

            for (int i = 0; i < fields.Length; i += 8)
            {
                machine.Buildings.Add(new MachinePart
                {
                    Type = "belt",
                    X = ParseInt(fields[i], "x tapis"),
                    Y = ParseInt(fields[i + 1], "y tapis"),
                    Rotation = NormalizeDirection(ParseInt(fields[i + 2], "direction tapis")),
                    Width = 1,
                    Height = 1
                });
            }
        }

        if (machine.Buildings.Count == 0)
            throw new InvalidDataException("Ce blueprint ne contient aucun bâtiment ni tapis reconnu.");
        if (machine.Buildings.Count > MaxBuildings)
            throw new InvalidDataException($"Ce blueprint contient plus de {MaxBuildings} éléments.");

        // The site computes its own normalized extents, but these fields are still useful metadata.
        int minX = machine.Buildings.Min(p => p.X);
        int minY = machine.Buildings.Min(p => p.Y);
        int maxX = machine.Buildings.Max(p => p.X + p.Width);
        int maxY = machine.Buildings.Max(p => p.Y + p.Height);
        machine.Width = Math.Clamp(maxX - minX, 1, 512);
        machine.Height = Math.Clamp(maxY - minY, 1, 512);
        return machine;
    }

    internal static string ToPrettyJson(Machine machine) => JsonSerializer.Serialize(machine, PrettyJson);

    internal static string EncodeClipboardString(Machine machine)
    {
        byte[] json = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(machine, CompactJson));
        using var output = new MemoryStream();
        using (var zlib = new ZLibStream(output, CompressionLevel.SmallestSize, leaveOpen: true))
            zlib.Write(json, 0, json.Length);
        return ClipboardPrefix + Convert.ToBase64String(output.ToArray());
    }

    internal static string DecodeClipboardString(string clipboard)
    {
        if (!clipboard.StartsWith(ClipboardPrefix, StringComparison.Ordinal))
            throw new InvalidDataException("Le presse-papiers ne contient pas de chaîne BMX1:.");

        string encoded = clipboard.Substring(ClipboardPrefix.Length).Trim();
        byte[] packed;
        try { packed = Convert.FromBase64String(encoded); }
        catch (FormatException ex) { throw new InvalidDataException("La chaîne BMX1: n'est pas un Base64 valide.", ex); }

        using var input = new MemoryStream(packed);
        using var zlib = new ZLibStream(input, CompressionMode.Decompress);
        using var output = new MemoryStream();
        byte[] buffer = new byte[8192];
        int read;
        while ((read = zlib.Read(buffer, 0, buffer.Length)) > 0)
        {
            if (output.Length + read > MaxJsonBytes)
                throw new InvalidDataException("La chaîne BMX1: dépasse la limite de décompression.");
            output.Write(buffer, 0, read);
        }
        return Encoding.UTF8.GetString(output.ToArray());
    }

    internal static string ExtractNativeXml(string jsonText)
    {
        if (string.IsNullOrWhiteSpace(jsonText) || jsonText.Length > MaxTextChars)
            throw new InvalidDataException("Le fichier .bmx est vide ou trop volumineux.");

        using JsonDocument doc = JsonDocument.Parse(jsonText, new JsonDocumentOptions { MaxDepth = 64 });
        JsonElement root = doc.RootElement;
        if (root.ValueKind != JsonValueKind.Object)
            throw new InvalidDataException("La racine du fichier .bmx doit être un objet JSON.");
        if (!root.TryGetProperty("format", out JsonElement format) || format.GetString() != FormatId)
            throw new InvalidDataException("Ce fichier n'est pas un blueprint Beltmatic Exchange valide.");
        if (!root.TryGetProperty("native_xml", out JsonElement xmlValue) || xmlValue.ValueKind != JsonValueKind.String)
            throw new InvalidDataException("Ce .bmx ne contient pas de XML natif du jeu : les démos fictives du site ne peuvent pas encore être importées dans Beltmatic.");

        return ExtractBlueprintXml(xmlValue.GetString() ?? "");
    }

    internal static string ReadBmxFile(string path)
    {
        var info = new FileInfo(path);
        if (!info.Exists || info.Length > MaxTextChars)
            throw new InvalidDataException("Le fichier .bmx est absent ou dépasse la taille autorisée.");
        return ExtractNativeXml(File.ReadAllText(path, Encoding.UTF8));
    }

    private static BclXDocument ParseSafeXml(string text)
    {
        if (string.IsNullOrWhiteSpace(text) || text.Length > MaxNativeXmlChars)
            throw new InvalidDataException("Le XML natif est vide ou trop volumineux.");
        if (text.IndexOf('\0') >= 0 || Regex.IsMatch(text, "<!\\s*(DOCTYPE|ENTITY)", RegexOptions.IgnoreCase))
            throw new InvalidDataException("Le XML contient une déclaration interdite.");

        var settings = new XmlReaderSettings
        {
            DtdProcessing = DtdProcessing.Prohibit,
            XmlResolver = null,
            MaxCharactersInDocument = MaxNativeXmlChars
        };
        using var reader = XmlReader.Create(new StringReader(text), settings);
        return BclXDocument.Load(reader);
    }

    private static string ExtractBlueprintXml(string text)
    {
        var doc = ParseSafeXml(text);
        BclXElement blueprint = FindBlueprint(doc);
        return blueprint.ToString(System.Xml.Linq.SaveOptions.DisableFormatting);
    }

    private static BclXElement FindBlueprint(BclXDocument doc)
    {
        if (doc.Root?.Name.LocalName == "Blueprint") return doc.Root;
        BclXElement blueprint = doc.Root?.DescendantsAndSelf().FirstOrDefault(e => e.Name.LocalName == "Blueprint");
        return blueprint ?? throw new InvalidDataException("Aucun élément <Blueprint> n'a été trouvé dans le XML.");
    }

    private static string ChildData(BclXElement blueprint, string childName) =>
        (string)blueprint.Elements().FirstOrDefault(e => e.Name.LocalName == childName)?.Attribute("Data");

    private static string[] SplitData(string data) => data.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);

    private static int ParseInt(string value, string what)
    {
        if (!int.TryParse(value, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out int n))
            throw new InvalidDataException($"Valeur invalide dans le XML ({what}).");
        return n;
    }

    private static int NormalizeDirection(int direction) => ((direction % 4) + 4) % 4;

    private static string Slug(string source)
    {
        string cleaned = new(source.Trim().ToLowerInvariant().Where(c =>
            (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-').ToArray());
        if (cleaned.Length == 0) cleaned = "unknown-building";
        return cleaned.Length > 32 ? cleaned[..32] : cleaned;
    }

    private static void SetKnownSize(MachinePart part)
    {
        switch (part.Type)
        {
            case "adder":
                part.Width = 2; part.Height = 2;
                break;
            case "multiplier":
                part.Width = (part.Rotation % 2 == 0) ? 3 : 1;
                part.Height = (part.Rotation % 2 == 0) ? 1 : 3;
                break;
            default:
                part.Width = 1; part.Height = 1;
                break;
        }
    }

    private static string CleanName(string name)
    {
        string safe = Regex.Replace(name ?? "", @"[\x00-\x1F\x7F]", " ");
        safe = Regex.Replace(safe, @"\s+", " ").Trim();
        if (safe.Length == 0) safe = "Beltmatic blueprint";
        return safe.Length > 80 ? safe[..80] : safe;
    }
}
