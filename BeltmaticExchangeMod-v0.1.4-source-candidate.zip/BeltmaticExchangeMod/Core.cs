using System.Text;
using System.Runtime.InteropServices;
using Il2Cpp;
using Il2CppNcp.Game;
using MelonLoader;
using MelonLoader.Utils;
using Il2CppXElement = Il2CppSystem.Xml.Linq.XElement;
using Il2CppBlueprint = Il2Cpp.Blueprint;
using Il2CppBlueprintList = Il2CppSystem.Collections.Generic.List<Il2Cpp.Blueprint>;

[assembly: MelonInfo(typeof(BeltmaticExchange.Core), "Beltmatic Exchange", "0.1.0", "Beltmatic Exchange")]
[assembly: MelonGame("Notional Games", "Beltmatic")]

namespace BeltmaticExchange;

public sealed class Core : MelonMod
{
    private const string GameVersion = "1.0.5";
    private const string ClipboardPrefix = "BMX1:";

    private string _rootDirectory = "";
    private string _exportsDirectory = "";
    private string _importsDirectory = "";
    private string _tempXmlPath = "";
    private bool _f7WasDown;
    private bool _f8WasDown;
    private bool _inputFailureLogged;

    // Read physical keys through Windows because Unity's legacy input call is throwing.
    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int virtualKey);

    private const int VkF7 = 0x76;
    private const int VkF8 = 0x77;

    public override void OnInitializeMelon()
    {
        _rootDirectory = Path.Combine(MelonEnvironment.UserDataDirectory, "BeltmaticExchange");
        _exportsDirectory = Path.Combine(_rootDirectory, "Exports");
        _importsDirectory = Path.Combine(_rootDirectory, "Imports");
        _tempXmlPath = Path.Combine(_rootDirectory, "_import_temp.xml");

        Directory.CreateDirectory(_exportsDirectory);
        Directory.CreateDirectory(_importsDirectory);

        MelonLogger.Msg("Beltmatic Exchange 0.1.0 loaded.");
        MelonLogger.Msg("F7 = exporter le blueprint sélectionné ; F8 = importer BMX1: ou le dernier .bmx dans UserData/BeltmaticExchange/Imports.");
    }

    public override void OnUpdate()
    {
        try
        {
            bool f7Down = (GetAsyncKeyState(VkF7) & 0x8000) != 0;
            bool f8Down = (GetAsyncKeyState(VkF8) & 0x8000) != 0;

            bool f7Pressed = f7Down && !_f7WasDown;
            bool f8Pressed = f8Down && !_f8WasDown;
            _f7WasDown = f7Down;
            _f8WasDown = f8Down;

            if (GameManager.Instance?.AnySimulation == null) return;

            if (f7Pressed)
                ExportSelectedBlueprint();

            if (f8Pressed)
                ImportBlueprint();
        }
        catch (Exception ex)
        {
            // Prevent repeated identical failures from flooding Latest.log.
            if (!_inputFailureLogged)
            {
                _inputFailureLogged = true;
                MelonLogger.Error($"Erreur dans Beltmatic Exchange (l'erreur ne sera plus répétée) : {ex}");
            }
        }
    }

    private void ExportSelectedBlueprint()
    {
        var manager = GameManager.Instance;
        if (manager == null || manager.simulationData == null)
        {
            MelonLogger.Warning("Impossible d'accéder aux données de la partie.");
            return;
        }

        var history = manager.simulationData.ClipboardHistory;
        if (history == null || history.Count == 0)
        {
            MelonLogger.Warning("Presse-papiers vide. Fais d'abord Ctrl+C dans Beltmatic, puis appuie sur F7.");
            return;
        }

        int index = manager.simulationData.CurrentClipboardIndex;
        if (index < 0 || index >= history.Count) index = history.Count - 1;
        var blueprint = history[index];
        if (blueprint == null)
        {
            MelonLogger.Warning("Le blueprint sélectionné est vide.");
            return;
        }

        Il2CppXElement nativeElement = blueprint.Serialize();
        if (nativeElement == null)
        {
            MelonLogger.Warning("Le jeu n'a pas pu sérialiser ce blueprint.");
            return;
        }

        string nativeXml = nativeElement.ToString();
        string name = $"Beltmatic {DateTime.Now:yyyy-MM-dd HH-mm-ss}";
        var machine = BmxCodec.FromNativeXml(nativeXml, name, GameVersion);
        string json = BmxCodec.ToPrettyJson(machine);
        string bmxPath = Path.Combine(_exportsDirectory, $"beltmatic-{DateTime.Now:yyyyMMdd-HHmmss}.bmx");
        File.WriteAllText(bmxPath, json, new UTF8Encoding(false));

        string importString = BmxCodec.EncodeClipboardString(machine);
        UnityEngine.GUIUtility.systemCopyBuffer = importString;

        MelonLogger.Msg($"Blueprint exporté : {bmxPath}");
        MelonLogger.Msg($"Chaîne BMX1: copiée dans le presse-papiers système. Tu peux la coller sur Beltmatic Exchange.");
    }

    private void ImportBlueprint()
    {
        if (GameManager.Instance?.AnySimulation == null)
        {
            MelonLogger.Warning("Charge une partie avant d'importer un blueprint.");
            return;
        }

        string clipboardText = UnityEngine.GUIUtility.systemCopyBuffer ?? "";
        string nativeXml;
        string sourceDescription;

        if (clipboardText.StartsWith(ClipboardPrefix, StringComparison.Ordinal))
        {
            string json = BmxCodec.DecodeClipboardString(clipboardText);
            nativeXml = BmxCodec.ExtractNativeXml(json);
            sourceDescription = "la chaîne BMX1: du presse-papiers";
        }
        else
        {
            string newestFile = Directory.EnumerateFiles(_importsDirectory, "*.bmx", SearchOption.TopDirectoryOnly)
                .Select(path => new FileInfo(path))
                .OrderByDescending(info => info.LastWriteTimeUtc)
                .Select(info => info.FullName)
                .FirstOrDefault();

            if (newestFile == null)
            {
                MelonLogger.Warning("Aucune chaîne BMX1: détectée et aucun fichier .bmx trouvé dans UserData/BeltmaticExchange/Imports.");
                MelonLogger.Msg("Copie une chaîne d'import depuis le site, ou place un .bmx dans le dossier Imports, puis appuie sur F8.");
                return;
            }

            nativeXml = BmxCodec.ReadBmxFile(newestFile);
            sourceDescription = newestFile;
        }

        // The game exposes the deserializer through Il2CppSystem.Xml.Linq, so load the
        // validated XML using that assembly rather than passing a normal .NET XElement.
        File.WriteAllText(_tempXmlPath, nativeXml, new UTF8Encoding(false));
        Il2CppXElement gameXml = Il2CppXElement.Load(_tempXmlPath);
        var simulation = GameManager.Instance.AnySimulation.Cast<ISimulation>();
        Il2CppBlueprint imported = Il2CppBlueprint.Deserialize(simulation, gameXml);
        if (imported == null)
            throw new InvalidDataException("Le jeu a refusé de désérialiser ce blueprint.");

        var data = GameManager.Instance.simulationData;
        var history = data.ClipboardHistory;
        if (history == null)
            history = new Il2CppBlueprintList();
        history.Add(imported);
        data.ClipboardHistory = history;
        data.CurrentClipboardIndex = history.Count - 1;

        MelonLogger.Msg($"Blueprint importé depuis {sourceDescription}.");
        MelonLogger.Msg("Appuie maintenant sur Ctrl+V dans le jeu pour le coller.");
    }
}
