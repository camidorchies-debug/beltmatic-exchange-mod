# Beltmatic Exchange — mod MelonLoader (première version)

Cette version relie le presse-papiers natif de Beltmatic au format `.bmx` / `BMX1:` utilisé par le site Beltmatic Exchange.

## Ce que fait cette version

- **F7 — Exporter :** utilise le blueprint actuellement sélectionné dans l'historique du presse-papiers du jeu, écrit un fichier `.bmx` et copie une chaîne `BMX1:` dans le presse-papiers Windows.
- **F8 — Importer :** importe la chaîne `BMX1:` actuellement copiée, ou, si le presse-papiers ne contient pas cette chaîne, le fichier `.bmx` le plus récent dans `UserData/BeltmaticExchange/Imports`.
- Après l'import, **Ctrl+V** dans Beltmatic place le blueprint avec le mécanisme natif du jeu.

Le mod ne publie pas automatiquement sur le site et n'envoie aucune requête Internet. Pour partager une machine, utilise F7 puis colle la chaîne `BMX1:` dans le champ d'import du site.

## Installation / compilation

1. Assure-toi que MelonLoader **0.7.3** est installé et que tu as déjà lancé Beltmatic une fois.
2. Installe le **SDK .NET 6** si nécessaire.
3. Décompresse ce dossier de projet où tu veux.
4. Si Beltmatic n'est pas installé dans le dossier Steam par défaut, donne le chemin du jeu à `build.bat` :

   ```bat
   build.bat "D:\SteamLibrary\steamapps\common\Beltmatic"
   ```

   Sinon double-clique simplement sur `build.bat`.
5. Le script compile le projet et copie `BeltmaticExchange.dll` dans le dossier `Beltmatic\Mods`.
6. Lance le jeu. Le journal MelonLoader doit afficher `Beltmatic Exchange 0.1.0 loaded`.

Le projet référence les assemblies produites par MelonLoader dans le dossier du jeu. Il n'intègre pas de copies de DLL du jeu.

## Utilisation

### Exporter une machine vers le site

1. Dans une partie, copie une zone de machine normalement avec `Ctrl+C`.
2. Appuie sur **F7**.
3. Le fichier `.bmx` est enregistré dans `Beltmatic\UserData\BeltmaticExchange\Exports`.
4. Une chaîne `BMX1:` est copiée dans le presse-papiers Windows. Colle-la sur le site pour prévisualiser et publier la machine.

### Importer une machine du site

**Méthode chaîne :** sur le site, clique sur le bouton qui copie la chaîne d'import. Dans Beltmatic, appuie sur **F8**, puis **Ctrl+V**.

**Méthode fichier :** télécharge le `.bmx` du site et place-le dans `Beltmatic\UserData\BeltmaticExchange\Imports`. Appuie sur F8 puis Ctrl+V. Si plusieurs fichiers sont présents, le plus récemment modifié est choisi.

## Limites de la première version

- Pour être importable dans Beltmatic, un `.bmx` doit contenir `native_xml`, c'est-à-dire les données XML originales du jeu. Les exemples fictifs fournis avec le site, qui n'ont pas ce champ, sont destinés à tester l'interface et ne peuvent pas être placés dans le jeu.
- L'aperçu du site est produit à partir des positions, types et rotations identifiés dans le XML. Les tapis et machines sont intégralement préservés dans `native_xml`, mais certaines informations de rendu (notamment priorités, directions multiples, ponts et ports détaillés) ne sont pas encore converties individuellement vers les champs d'aperçu du `.bmx`.
- Les touches F7/F8 sont codées en dur pour cette version.
- **Cette archive contient le code source et le script de compilation, pas une DLL compilée.** Il faut compiler avec les assemblies MelonLoader de ton installation. Je n'ai pas pu lancer le compilateur dans cet environnement, donc cette première version doit encore être compilée et testée en jeu.

## Dépannage

- Si `build.bat` ne trouve pas `Assembly-CSharp.dll`, vérifie le chemin donné au script et que le dossier `MelonLoader/Il2CppAssemblies` existe.
- Si la compilation indique qu'il manque le SDK .NET, installe le SDK .NET 6 (pas seulement le runtime).
- Si F7 indique que le presse-papiers est vide, fais d'abord `Ctrl+C` dans le jeu.
- Si F8 indique que le `.bmx` ne contient pas de XML natif, essaie une machine exportée par le mod plutôt qu'un exemple fictif.


## v0.1.4 candidate — dépannage des touches

Cette version candidate utilise l'API Windows `GetAsyncKeyState` à la place de l'ancienne API d'entrée Unity, qui déclenchait une `SEHException` dans le journal. Les erreurs répétées dans `OnUpdate` sont également limitées à une seule entrée.
Raccourcis : F7 exporte le blueprint présent dans l'historique du presse-papiers du jeu ; F8 importe la chaîne `BMX1:` du presse-papiers système, ou le fichier `.bmx` le plus récent du dossier `UserData/BeltmaticExchange/Imports`.
